from lib.ColoredObject import Color

ColorObj = Color()
